import application.Bateria;
import application.Celular;

void main() {
    Bateria bateria = new Bateria ( 60,  4000);
    Celular celular = new Celular("xiomi", "japones",bateria);

    celular.carregarCelular();
    celular.usarCelular(100);
    celular.carregarCelular();
    celular.usarCelular(20);

    System.out.println(celular);
}